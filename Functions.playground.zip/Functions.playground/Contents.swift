import UIKit

func test(){
    print("Hello World")
}

// Calling a func
test()

// Input
func test2(a : Int, b : Int){
    if a>b {
        print(a,"is greater than ",b)
        
    } else{
        
        print(b,"is greater than ",a)
    }
    
}

test2(a: 7, b: 9)

// Returning outputs using -> method


func test3(a : Int, b : Int) -> Bool {
    if a>b {
        
        return true
    } else{
        return false
        
    }
    
}

test3(a: 6, b: 4)

