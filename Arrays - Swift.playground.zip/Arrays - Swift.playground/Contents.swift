import UIKit

var myFavCh = ["TMKOC","TYHM","Krishna"]
myFavCh[0].uppercased()
myFavCh.count
myFavCh.last
myFavCh.sort()

var mynum = [1,3,2,34,243,4,58]
mynum.sort()


// Sets
var mySet : Set = [1,2,3,4,5]
var myStringSet : Set = ["a","b","c","a"]

var myInternetArray = [1,3,5,2,1,3,4,2,3,5,4,5,3,2,5,]
var myInternetSet = Set(myInternetArray)
print(myInternetArray)
print(myInternetSet)

var mySet1 : Set = [1,2,3]
var mySet2 : Set = [4,5,6]

var mySet3 = mySet1.union(mySet2)
print(mySet3)

// Dictionaries

var myDict = ["Tanish" : 12 , "Bhuvi" : 8 , "Father" : 40 , "Mother" : 40]

myDict["Tanish"]
myDict["Mother"]
myDict["GrandFather"] = 70
print(myDict)
