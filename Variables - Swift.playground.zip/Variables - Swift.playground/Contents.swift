import UIKit
// Variables and constants


// snake case
// var user_name =

// Camel Case

// Strings
var userName = "Bhuvi"
userName.append("ka")
userName.lowercased()
userName.uppercased()
var userSurname = "Kapur"
// Changing UserName

userName = "Tanish"

// Constants
let name = "Tanish"
// integer
var int = 65

//Double
var dou = 65.0

let pi = 3.14
var uAge = 30.0
uAge + pi

var myBool = true
myBool = false
var num : Int = Int(9.9)

