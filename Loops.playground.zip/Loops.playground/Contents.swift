import UIKit

var num = 0

// While loop

while num <= 10 {
    //print(num)
    num += 1
}

// For loops
var myFruit = ["Apple", "Mango", "Banana"]
for fruits in myFruit{
    print(fruits)
}

var myNum = [1,2,3,4,5,6,7,8,9,10]

for num in myNum{
    print(num / 5)
}


