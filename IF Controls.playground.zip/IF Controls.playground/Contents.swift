import UIKit

var myAge = 12

if myAge < 10 {
    print("10 -")
}else if myAge > 10{
    print("10 +")
}







